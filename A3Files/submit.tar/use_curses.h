






#ifndef USECURSES_H
#define USECURSES_H



/* Function Prototypes */

void start_curses();
void end_curses();




#endif
